"""Reusable presentation widgets: cards, stat tiles, tables, banners."""

from __future__ import annotations

from PySide6.QtCore import (
    QAbstractTableModel,
    QEvent,
    QModelIndex,
    QObject,
    QSize,
    QSortFilterProxyModel,
    Qt,
)
from PySide6.QtGui import QColor, QFont, QPainter
from PySide6.QtWidgets import (
    QAbstractItemView,
    QApplication,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QPushButton,
    QToolButton,
    QToolTip,
    QSizePolicy,
    QTableView,
    QVBoxLayout,
    QWidget,
)

from . import teamlogos
from .theme import DARK, PALETTES, Palette, contrast, tone_color
from .tokens import SPACE

#: The tones a widget may be given; anything else is treated as no tone.
TONES = ("good", "warning", "serious", "bad", "muted")


def theme_palette() -> Palette:
    """The palette the window is wearing (app.apply_theme names it on the
    application), for a widget that has to draw in its colours."""
    app = QApplication.instance()
    name = app.property("theme") if app is not None else None
    return PALETTES.get(name if isinstance(name, str) else "dark", DARK)


class IconButton(QPushButton):
    """A button with one of the dashboard's own icons (icons.py) beside its
    words, redrawn in the theme's colours whenever the theme changes."""

    def __init__(self, text: str = "", icon: str = "", parent: QWidget | None = None, size: int = 15) -> None:
        super().__init__(parent)
        self._icon, self._size = icon, size
        self.setIconSize(QSize(size, size))
        self.setText(text)
        self._draw()

    def setText(self, text: str) -> None:  # noqa: N802 (Qt naming)
        # a little air between the icon and the words
        super().setText(f"  {text.strip()}" if text.strip() else "")

    def setObjectName(self, name: str) -> None:  # noqa: N802
        super().setObjectName(name)
        self._draw()            # a primary button's icon is drawn for its own background

    def changeEvent(self, event) -> None:  # noqa: N802
        super().changeEvent(event)
        if event.type() == QEvent.Type.StyleChange:
            self._draw()

    def _draw(self) -> None:
        from . import icons
        p = theme_palette()
        if self.objectName() == "Primary":
            colour = "#05070a" if contrast(p.accent, "#05070a") >= contrast(p.accent, "#ffffff") else "#ffffff"
        else:
            colour = p.ink_secondary
        if (self._icon, colour) != getattr(self, "_drawn", None):
            self._drawn = (self._icon, colour)
            self.setIcon(icons.icon(self._icon, colour, size=self._size))


class ElidedLabel(QLabel):
    """A one-line label that ends in an ellipsis instead of widening its parent.

    A plain QLabel refuses to shrink below its text, so a long player name in
    a big headline tile pushes the whole row wider than the window. This one
    shrinks and shows the full text as a tooltip when it has been cut.
    """

    def __init__(self, text: str = "", parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._full = ""
        self.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
        self.setText(text)

    def setText(self, text: str) -> None:  # noqa: N802 (Qt naming)
        self._full = text
        self._elide()

    def full_text(self) -> str:
        return self._full

    def minimumSizeHint(self) -> QSize:  # noqa: N802
        return QSize(0, super().minimumSizeHint().height())

    def resizeEvent(self, event) -> None:  # noqa: N802
        super().resizeEvent(event)
        self._elide()

    def changeEvent(self, event) -> None:  # noqa: N802
        super().changeEvent(event)
        # The stylesheet sets the font after construction; re-measure with it.
        if event.type() in (QEvent.Type.FontChange, QEvent.Type.StyleChange):
            self._elide()

    def _elide(self) -> None:
        shown = self.fontMetrics().elidedText(
            self._full, Qt.TextElideMode.ElideRight, max(self.width(), 0)
        )
        if shown != self.text():
            super().setText(shown)
        self.setToolTip(self._full if shown != self._full else "")


class InfoIcon(QToolButton):
    """A small \u24d8 that explains a figure - on hover, on keyboard focus, or on a click.

    Tooltips alone only answer a mouse; this one also opens for someone
    tabbing through the page, and a screen reader is given the same words.
    """

    def __init__(self, text: str, name: str = "", parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setObjectName("InfoIcon")
        self.setText("\u24d8")
        self.setAutoRaise(True)
        self.setCursor(Qt.CursorShape.WhatsThisCursor)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.setAccessibleName(f"About {name}" if name else "More about this")
        self.clicked.connect(self._show)
        self.set_text(text)

    def set_text(self, text: str) -> None:
        self._text = text
        self.setToolTip(text)
        self.setAccessibleDescription(text)

    def _show(self) -> None:
        if self._text:
            QToolTip.showText(self.mapToGlobal(self.rect().bottomLeft()), self._text, self)

    def focusInEvent(self, event) -> None:  # noqa: N802 (Qt naming)
        super().focusInEvent(event)
        self._show()

    def focusOutEvent(self, event) -> None:  # noqa: N802 (Qt naming)
        super().focusOutEvent(event)
        QToolTip.hideText()


def with_info(widget: QWidget, text: str, name: str = "") -> QWidget:
    """`widget` with an \u24d8 beside it, as one row."""
    row = QWidget()
    lay = QHBoxLayout(row)
    lay.setContentsMargins(0, 0, 0, 0)
    lay.setSpacing(4)
    lay.addWidget(widget)
    lay.addWidget(InfoIcon(text, name), 0, Qt.AlignmentFlag.AlignVCenter)
    lay.addStretch(1)
    return row


class Card(QFrame):
    """A titled surface. The title is a quiet label, not a heading.

    `info`, if given, puts an \u24d8 beside the title explaining what the card shows.
    """

    def __init__(self, title: str = "", parent: QWidget | None = None, info: str = "") -> None:
        super().__init__(parent)
        self.setObjectName("Card")
        self._layout = QVBoxLayout(self)
        self._layout.setContentsMargins(SPACE["room"], SPACE["step"], SPACE["room"], SPACE["room"])
        self._layout.setSpacing(SPACE["step"])
        # A card given more height than it needs keeps its contents at the
        # top. Otherwise the spare height was shared out between the items,
        # and a title label - which centres its text in whatever it is
        # given - drifted down into the middle of an empty card.
        self._layout.setAlignment(Qt.AlignmentFlag.AlignTop)
        self.title_label: QLabel | None = None
        self.info_icon: InfoIcon | None = None
        if title:
            self.title_label = QLabel(title)
            self.title_label.setObjectName("CardTitle")
            if info:
                self.info_icon = InfoIcon(info, title)
                head = QHBoxLayout()
                head.setSpacing(4)
                head.addWidget(self.title_label)
                head.addWidget(self.info_icon, 0, Qt.AlignmentFlag.AlignVCenter)
                head.addStretch(1)
                self._layout.addLayout(head)
            else:
                self._layout.addWidget(self.title_label)

    def body(self) -> QVBoxLayout:
        return self._layout

    def add(self, widget: QWidget, stretch: int = 0) -> QWidget:
        self._layout.addWidget(widget, stretch)
        return widget

    def set_title(self, title: str) -> None:
        if self.title_label is not None:
            self.title_label.setText(title)


class StatTile(Card):
    """A single headline number. No plot, so no hover layer is needed."""

    def __init__(
        self,
        title: str,
        value: str = "-",
        detail: str = "",
        parent: QWidget | None = None,
        info: str = "",
    ) -> None:
        # What a tile measures is set in small capitals, as on an instrument.
        super().__init__(title.upper(), parent, info=info)
        if self.info_icon is not None:
            self.info_icon.setAccessibleName(f"About {title}")
        # A different object name lets the theme lift tiles above the cards.
        self.setObjectName("StatTile")
        self._palette: Palette | None = None
        self.bar: Sparkbar | None = None
        self.value_label = ElidedLabel(value)
        self.value_label.setObjectName("StatValue")
        self.value_label.setWordWrap(False)
        self.detail_label = QLabel(detail)
        self.detail_label.setObjectName("StatDetail")
        self.detail_label.setProperty("tone", "")
        self.detail_label.setWordWrap(True)
        self._layout.addWidget(self.value_label)
        self._layout.addWidget(self.detail_label)
        self._layout.addStretch(1)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        self.setMinimumHeight(112)

    def set_title(self, title: str) -> None:
        super().set_title(title.upper())

    def update_values(self, value: str, detail: str = "", tone: str = "") -> None:
        self.value_label.setText(value)
        self.detail_label.setText(detail)
        # A headline that is a team name, not a number, steps the type down
        # rather than eliding - losing the end of "San Francisco" is worse
        # than showing it smaller.
        length = "verylong" if len(value) > 15 else ("long" if len(value) > 9 else "")
        self._restyle(self.value_label, "length", length)
        # Whether the headline is a figure or a phrase ("7-way tie", "New York
        # Giants"), for a theme that wants to set the two differently.
        self._restyle(
            self.value_label, "kind",
            "text" if not any(c.isdigit() for c in value) else "",
        )
        # Tone rides on the detail line; the big number stays in primary ink so
        # a colour never has to carry the meaning on its own. It is a property
        # rather than a new object name so the label keeps its size and font.
        self._restyle(self.detail_label, "tone", tone if tone in TONES else "")

    def show_bar(
        self,
        value: float,
        marker: float | None = None,
        tone: str = "",
        palette: Palette | None = None,
    ) -> None:
        """Add a hairline bar under the number, against an optional reference.

        Used where a figure only means something next to another one - a hit
        rate against the pool's, a share against an average. A palette is
        needed to draw it; without one the tile simply keeps its number.
        """
        self._palette = palette or self._palette
        if self._palette is None:
            return
        if self.bar is None:
            self.bar = Sparkbar(self._palette)
            self._layout.insertWidget(self._layout.count() - 1, self.bar)
        self.bar.set_values(value, marker, tone)
        self.bar.show()

    def hide_bar(self) -> None:
        if self.bar is not None:
            self.bar.hide()

    def set_palette(self, palette: Palette) -> None:
        self._palette = palette
        if self.bar is not None:
            self.bar.set_palette(palette)

    @staticmethod
    def _restyle(widget: QWidget, name: str, value: str) -> None:
        widget.setProperty(name, value)
        widget.style().unpolish(widget)
        widget.style().polish(widget)


class Pill(QLabel):
    """One figure in a tinted chip, for a number that sits among words."""

    def __init__(self, text: str = "", tone: str = "", parent: QWidget | None = None) -> None:
        super().__init__(text, parent)
        self.setObjectName("Pill")
        self.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.set_tone(tone)

    def set_tone(self, tone: str) -> None:
        self.setProperty("tone", tone if tone in TONES else "")
        self.style().unpolish(self)
        self.style().polish(self)

    def update_values(self, text: str, tone: str = "") -> None:
        self.setText(text)
        self.set_tone(tone)


class Sparkbar(QWidget):
    """A hairline bar showing one proportion, with an optional marker.

    Made for a figure that only means something against a reference - a
    player's hit rate against the pool's, a share of the pool against an
    average. The number says how much; this says how much compared with what.
    """

    def __init__(
        self,
        palette: Palette,
        height: int = 6,
        parent: QWidget | None = None,
    ) -> None:
        super().__init__(parent)
        self.palette_ = palette
        self._value = 0.0
        self._marker: float | None = None
        self._tone = ""
        self.setFixedHeight(height)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)

    def set_palette(self, palette: Palette) -> None:
        self.palette_ = palette
        self.update()

    def set_values(self, value: float, marker: float | None = None, tone: str = "") -> None:
        """`value` and `marker` are 0..1; anything outside is clamped."""
        self._value = min(max(float(value), 0.0), 1.0)
        self._marker = None if marker is None else min(max(float(marker), 0.0), 1.0)
        self._tone = tone
        self.update()

    def paintEvent(self, event) -> None:  # noqa: N802 (Qt naming)
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        p = self.palette_
        radius = self.height() / 2
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(QColor(p.grid))
        painter.drawRoundedRect(self.rect(), radius, radius)
        filled = int(self.width() * self._value)
        if filled > 0:
            painter.setBrush(QColor(tone_color(p, self._tone) if self._tone else p.accent))
            bar = self.rect()
            bar.setWidth(max(filled, self.height()))
            painter.drawRoundedRect(bar, radius, radius)
        if self._marker is not None:
            x = int(self.width() * self._marker)
            painter.setBrush(QColor(p.ink))
            painter.drawRect(max(0, min(x - 1, self.width() - 2)), 0, 2, self.height())
        painter.end()


def tile_grid(tiles: list[QWidget], per_row: int = 4, spacing: int = 12) -> QGridLayout:
    """Lay tiles out in rows rather than squeezing them all onto one line.

    Six tiles across a laptop screen leaves each one too narrow to hold its
    own number, and the value label quietly elides. Wrapping at four keeps
    every tile readable at any window width.

    The first tile is the page's headline - the leader, the week's winner,
    your own score - and is marked as the lead so the theme can light it and
    leave the rest quiet.
    """
    grid = QGridLayout()
    grid.setSpacing(spacing)
    if tiles and isinstance(tiles[0], StatTile):
        tiles[0].setProperty("lead", True)
    for index, tile in enumerate(tiles):
        grid.addWidget(tile, index // per_row, index % per_row)
    for column in range(min(per_row, len(tiles))):
        grid.setColumnStretch(column, 1)
    return grid


class Banner(QFrame):
    """Notes about the loaded files: one line, with the rest on request.

    Four or five notes stacked at the top of a page pushed the page itself
    down a quarter of the screen on every visit. The first note is shown in
    full and the others wait behind "Show all", so the banner says that
    there is something to read without making you read it every time.
    """

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setObjectName("Banner")
        layout = QHBoxLayout(self)
        layout.setContentsMargins(SPACE["step"], SPACE["snug"], SPACE["snug"], SPACE["snug"])
        layout.setSpacing(SPACE["snug"])
        self.icon = QLabel("\N{WARNING SIGN}")
        self.icon.setObjectName("BannerIcon")
        self.label = QLabel("")
        self.label.setWordWrap(True)
        self.label.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        self.toggle = QPushButton("")
        self.toggle.setObjectName("BannerToggle")
        self.toggle.setFlat(True)
        self.toggle.setCursor(Qt.CursorShape.PointingHandCursor)
        self.toggle.clicked.connect(self._flip)
        layout.addWidget(self.icon, 0, Qt.AlignmentFlag.AlignTop)
        layout.addWidget(self.label, 1)
        layout.addWidget(self.toggle, 0, Qt.AlignmentFlag.AlignTop)
        self._messages: list[str] = []
        self._expanded = False
        self.hide()

    def show_messages(
        self, messages: list[str], icon: str = "\N{WARNING SIGN}", tone: str = "warning",
    ) -> None:
        text = [m for m in messages if m]
        if not text:
            self._messages = []
            self.hide()
            return
        if text != self._messages:
            self._expanded = False          # new notes start folded
        self._messages = text
        self._mark, self._tone = icon, tone
        self.setProperty("tone", tone)
        self.style().unpolish(self)
        self.style().polish(self)
        self._draw_icon()
        self._render()
        self.show()

    def changeEvent(self, event) -> None:  # noqa: N802 (Qt naming)
        super().changeEvent(event)
        if event.type() == QEvent.Type.StyleChange and getattr(self, "_messages", None):
            self._draw_icon()

    def _draw_icon(self) -> None:
        """The mark beside the notes: one of the dashboard's own icons in the
        banner's colour, or whatever character was asked for."""
        from . import icons
        mark, tone = getattr(self, "_mark", "\N{WARNING SIGN}"), getattr(self, "_tone", "warning")
        name = mark
        if mark == "\N{WARNING SIGN}":
            name = "info" if tone == "info" else "alert"
        p = theme_palette()
        colour = p.accent if tone == "info" else p.warning
        if (name, colour) == getattr(self, "_drawn", None):
            return
        self._drawn = (name, colour)
        if name in icons.ICONS and icons.QSvgRenderer is not None:
            self.icon.setPixmap(icons.pixmap(name, colour, size=17))
        else:
            self.icon.setText(mark)

    def _flip(self) -> None:
        self._expanded = not self._expanded
        self._render()

    def _render(self) -> None:
        text = self._messages
        if len(text) == 1:
            self.label.setText(text[0])
            self.toggle.hide()
            return
        self.toggle.show()
        if self._expanded:
            self.label.setText("\n".join(f"\u2022  {m}" for m in text))
            self.toggle.setText("Show less")
        else:
            more = len(text) - 1
            self.label.setText(text[0])
            self.toggle.setText(f"Show all {len(text)}  ({more} more)")


class TableModel(QAbstractTableModel):
    """A table over plain rows, with per-column alignment and optional tone.

    `rows` are display-ready values. `sort_values` supplies the value used for
    ordering where it differs from what is shown (so "-39.97" sorts
    numerically while displaying as "-$39.97").
    """

    def __init__(
        self,
        headers: list[str],
        rows: list[list[object]],
        *,
        palette: Palette,
        numeric_columns: set[int] | None = None,
        sort_values: dict[int, list[object]] | None = None,
        tones: dict[tuple[int, int], str] | None = None,
        cell_colors: dict[tuple[int, int], str] | None = None,
        tooltips: dict[tuple[int, int], str] | None = None,
        bold_columns: set[int] | None = None,
    ) -> None:
        super().__init__()
        self._headers = headers
        self._rows = rows
        self._palette = palette
        self._numeric = numeric_columns or set()
        self._sort_values = sort_values or {}
        self._tones = tones or {}
        self._cell_colors = cell_colors or {}
        self._tooltips = tooltips or {}
        self._bold = bold_columns or set()
        self._bold_font = QFont()
        self._bold_font.setBold(True)
        self._sorted: tuple[int, bool] = (-1, True)     # column, ascending (mark_sorted)

        # Everything below is worked out once, because `data()` is called by
        # Qt for every cell, for half a dozen roles, on every paint, sort and
        # resize - tens of thousands of calls for one table. Anything built
        # inside it is built that many times. A QColor per cell per paint was
        # most of why the tables felt heavy.
        self._text = [
            ["" if value is None else str(value) for value in row] for row in rows
        ]
        self._align = [
            int(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
            if column in self._numeric else
            int(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
            for column in range(len(headers))
        ]
        self._tone_colors = {
            "good": QColor(palette.good),
            "warning": QColor(palette.warning),
            "bad": QColor(palette.critical),
            "muted": QColor(palette.ink_muted),
            # first place: the gold, as on the name
            "lead": QColor(palette.brand or palette.accent),
        }
        self._foreground = {
            cell: self._tone_colors.get(tone)
            for cell, tone in self._tones.items()
        }
        self._background = {
            cell: QColor(color) for cell, color in self._cell_colors.items() if color
        }
        # A team's logo beside its name, wherever a cell names one.
        self._logos = {
            (r, c): code
            for r, row in enumerate(self._text) for c, text in enumerate(row)
            if c not in self._numeric and (code := teamlogos.code_in(text))
        }

    def rowCount(self, parent: QModelIndex = QModelIndex()) -> int:  # noqa: N802
        return 0 if parent.isValid() else len(self._rows)

    def columnCount(self, parent: QModelIndex = QModelIndex()) -> int:  # noqa: N802
        return 0 if parent.isValid() else len(self._headers)

    def headerData(self, section, orientation, role=Qt.ItemDataRole.DisplayRole):  # noqa: N802
        if orientation == Qt.Orientation.Horizontal and role == Qt.ItemDataRole.ToolTipRole:
            return self._headers[section]       # the whole label, when a narrow column elides it
        if orientation == Qt.Orientation.Horizontal and role == Qt.ItemDataRole.TextAlignmentRole:
            # A heading sits over its column's own edge: figures are set to
            # the right, so a centred heading floated off to one side of them.
            return self._align[section] if 0 <= section < len(self._align) else None
        if role != Qt.ItemDataRole.DisplayRole:
            return None
        if orientation == Qt.Orientation.Horizontal:
            label = self._headers[section]
            if section == self._sorted[0]:
                # The sort arrow is part of the heading, on the side away from
                # the column's edge, so it can never sit on top of the label.
                arrow = "\N{BLACK UP-POINTING SMALL TRIANGLE}" if self._sorted[1] else "\N{BLACK DOWN-POINTING SMALL TRIANGLE}"
                return f"{arrow} {label}" if section in self._numeric else f"{label} {arrow}"
            return label
        return section + 1

    def mark_sorted(self, column: int, ascending: bool) -> None:
        """Say which column the view is sorted by, for the arrow in its heading."""
        was, self._sorted = self._sorted, (column, ascending)
        for changed in {was[0], column}:
            if 0 <= changed < len(self._headers):
                self.headerDataChanged.emit(Qt.Orientation.Horizontal, changed, changed)

    def data(self, index: QModelIndex, role=Qt.ItemDataRole.DisplayRole):
        if not index.isValid():
            return None
        row, col = index.row(), index.column()

        # Ordered by how often Qt asks: display and alignment on every cell of
        # every paint, the rest only where something was set.
        if role == Qt.ItemDataRole.DisplayRole:
            return self._text[row][col]
        if role == Qt.ItemDataRole.TextAlignmentRole:
            return self._align[col]
        if role == Qt.ItemDataRole.ForegroundRole:
            return self._foreground.get((row, col))
        if role == Qt.ItemDataRole.DecorationRole:
            code = self._logos.get((row, col))
            return teamlogos.icon(code) if code else None
        if role == Qt.ItemDataRole.BackgroundRole:
            return self._background.get((row, col))
        if role == Qt.ItemDataRole.ToolTipRole:
            return self._tooltips.get((row, col))
        if role == Qt.ItemDataRole.FontRole and col in self._bold:
            return self._bold_font
        if role == Qt.ItemDataRole.UserRole:
            value = self._rows[row][col]
            # The sort key: explicit override, else the raw value.
            override = self._sort_values.get(col)
            return override[row] if override is not None else value
        return None

    def row_values(self, row: int) -> list[object]:
        return self._rows[row]


class SortProxy(QSortFilterProxyModel):
    """Sorts on UserRole so numbers order numerically, and filters on text."""

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setSortRole(Qt.ItemDataRole.UserRole)
        self.setFilterCaseSensitivity(Qt.CaseSensitivity.CaseInsensitive)
        self._filter_columns: list[int] = []

    def set_filter_columns(self, columns: list[int]) -> None:
        self._filter_columns = columns

    def filterAcceptsRow(self, source_row: int, source_parent: QModelIndex) -> bool:  # noqa: N802
        pattern = self.filterRegularExpression().pattern()
        if not pattern:
            return True
        model = self.sourceModel()
        columns = self._filter_columns or range(model.columnCount())
        for col in columns:
            index = model.index(source_row, col, source_parent)
            text = str(model.data(index, Qt.ItemDataRole.DisplayRole) or "")
            if pattern.lower() in text.lower():
                return True
        return False

    def lessThan(self, left: QModelIndex, right: QModelIndex) -> bool:  # noqa: N802
        a = self.sourceModel().data(left, Qt.ItemDataRole.UserRole)
        b = self.sourceModel().data(right, Qt.ItemDataRole.UserRole)
        # Blanks sort first. Two blanks are equal, not "each less than the
        # other", which would give the sort an inconsistent order.
        if a is None or b is None:
            return a is None and b is not None
        try:
            return float(a) < float(b)
        except (TypeError, ValueError):
            return str(a).lower() < str(b).lower()


# No single column may take more than this. A "Why" or a matchup runs long,
# and a column sized to its longest entry pushes every column after it off the
# edge of the card - so the table scrolls sideways to reach a two-character
# number. Capped, the long text elides with an ellipsis and the rest of the
# row stays on screen, which is the right trade: the full text is one hover
# away, the numbers are the reason the table is there.
MAX_COLUMN_WIDTH = 240
#: Tables show this many rows before they scroll inside themselves. Every
#: table in the app is shorter than this (35 coaches, 16 games), so in
#: practice the page scrolls and the table never does - a box you have to
#: scroll inside a page you are also scrolling hid most of every table.
FIT_ROWS = 40
#: A column squeezed to fit the window never goes narrower than this.
COLUMN_FLOOR = 48
#: And the sentence column ("Why", "Player") keeps at least this much.
STRETCH_FLOOR = 180


def fit_height(view: QAbstractItemView, rows: int, row_height: int, most: int = FIT_ROWS) -> None:
    """Make a table exactly tall enough for its rows, up to `most`.

    A table taller than `most` rows still scrolls inside itself; one shorter
    takes exactly its own height, so a 3-row table is not a 300-pixel box.
    The vertical scroll bar is left on "as needed" so that if the header
    comes out taller than measured, the last row is reachable rather than
    silently cut off.
    """
    header = view.horizontalHeader()
    head = max(header.height(), header.sizeHint().height(), 30)
    shown = max(1, min(rows, most))
    frame = view.frameWidth() * 2
    view.setFixedHeight(head + shown * row_height + frame + 4)
    view.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)


def fit_widths(natural: dict[int, int], values: dict[int, int], room: int) -> dict[int, int]:
    """Column widths that fit in `room`, giving way in the order that costs least.

    `natural` is each column's measured width (its header or its widest value,
    whichever is wider); `values` is what its values alone need. First the
    widest columns come down to a common width but never below their values,
    so only header labels elide (they're on the hover) and every number shows
    whole - "$106.00", never "$106...". Only when the values themselves don't
    fit does a column go narrower than its values, down to COLUMN_FLOOR.
    """
    if sum(natural.values()) <= room or room <= 0:
        return dict(natural)
    floor = {c: min(w, max(COLUMN_FLOOR, values.get(c, COLUMN_FLOOR))) for c, w in natural.items()}

    def capped(cap: float, least: dict[int, int]) -> dict[int, int]:
        return {c: max(least[c], min(w, int(cap))) for c, w in natural.items()}

    least = floor if sum(floor.values()) <= room else {c: min(w, COLUMN_FLOOR) for c, w in natural.items()}
    # The largest common cap that fits: every column keeps its own width up to
    # the cap, the wide ones come down to it (and no further than `least`).
    low, high = 0.0, float(max(natural.values()))
    for _ in range(24):
        mid = (low + high) / 2
        if sum(capped(mid, least).values()) > room:
            high = mid
        else:
            low = mid
    return capped(low, least)


class ColumnFitter(QObject):
    """Keeps a table's columns inside its width, so it never scrolls sideways.

    Columns are measured once (see make_table). When the window is too
    narrow for all of them, the widest are trimmed first (fit_widths): header
    labels elide before any value does, and the full label is on the hover.
    The sentence column takes whatever is left - at least STRETCH_FLOOR, or
    just its own values' width when the numbers need the room.
    """

    def __init__(self, view: QAbstractItemView, stretch: int | None,
                 values: dict[int, int] | None = None) -> None:
        super().__init__(view)
        self.view = view
        self.stretch = stretch
        self.values = dict(values or {})
        self.natural: list[int] = []
        self.remeasure()
        view.viewport().installEventFilter(self)

    def remeasure(self) -> None:
        header = self.view.horizontalHeader()
        self.natural = [header.sectionSize(c) for c in range(header.count())]
        self.fit()

    def eventFilter(self, obj, event) -> bool:  # noqa: N802 (Qt naming)
        if event.type() == QEvent.Type.Resize:
            self.fit()
        return False

    def fit(self) -> None:
        try:
            header = self.view.horizontalHeader()
            width = self.view.viewport().width()
        except RuntimeError:            # the table is being torn down
            return
        if width <= 0 or not self.natural:
            return
        shown = [
            c for c in range(min(header.count(), len(self.natural)))
            if not header.isSectionHidden(c) and c != self.stretch
        ]
        want = {c: self.natural[c] for c in shown}
        values = {c: self.values.get(c, COLUMN_FLOOR) for c in shown}
        room = width
        if self.stretch is not None:
            room -= STRETCH_FLOOR
            # Names need less than the floor: the numbers get the difference.
            floors = sum(min(w, max(COLUMN_FLOOR, values[c])) for c, w in want.items())
            if floors > room:
                room = width - max(COLUMN_FLOOR, min(STRETCH_FLOOR, self.values.get(self.stretch, STRETCH_FLOOR)))
        for c, w in fit_widths(want, values, room).items():
            if header.sectionSize(c) != w:
                header.resizeSection(c, w)


def current_sort(view, columns: int, default: tuple[int, bool] = (0, True)) -> tuple[int, bool]:
    """A table's current (column, ascending), or the default if unknown.

    Tables are rebuilt on every refresh, which resets the sort indicator, so
    the reader's choice has to be read off the old one and carried across.
    """
    if view is None or not hasattr(view, "horizontalHeader"):
        return default
    header = view.horizontalHeader()
    column = header.sortIndicatorSection()
    if not 0 <= column < columns:
        return default
    return column, header.sortIndicatorOrder() == Qt.SortOrder.AscendingOrder


def make_table(
    model: TableModel,
    *,
    stretch_column: int | None = None,
    sort_column: int | None = None,
    ascending: bool = True,
    row_height: int = 30,
    max_column_width: int = MAX_COLUMN_WIDTH,
    fit_rows: int | None = FIT_ROWS,
) -> tuple[QTableView, SortProxy]:
    """Build a configured table view over a model.

    With no `sort_column` the rows stay in the order the page gave them
    until a header is clicked. (Turning sorting on otherwise sorts at once by
    the first column, descending - which is why This Week's card used to
    start at game 16.) `fit_rows` sizes the table to its rows; pass None to
    size it yourself.
    """
    proxy = SortProxy()
    proxy.setSourceModel(model)
    view = QTableView()
    view.setModel(proxy)
    view.setAlternatingRowColors(True)
    view.setShowGrid(False)
    view.setWordWrap(False)
    view.verticalHeader().setVisible(False)
    view.verticalHeader().setDefaultSectionSize(row_height)
    view.verticalHeader().setMinimumSectionSize(row_height)
    view.setSelectionBehavior(QTableView.SelectionBehavior.SelectRows)
    view.setSelectionMode(QTableView.SelectionMode.SingleSelection)
    view.setEditTriggers(QTableView.EditTrigger.NoEditTriggers)
    view.setHorizontalScrollMode(QTableView.ScrollMode.ScrollPerPixel)
    view.setVerticalScrollMode(QTableView.ScrollMode.ScrollPerPixel)
    view.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)

    header = view.horizontalHeader()
    header.setHighlightSections(False)
    header.setMinimumSectionSize(COLUMN_FLOOR)
    # Columns are measured once, here, rather than left on ResizeToContents.
    # That mode re-measures every cell of every column on every sort, scroll
    # and repaint, and each measurement asks the model for the cell - which
    # for a seventeen-column table of thirty-five coaches is the difference
    # between a page that opens and a window that stops answering.
    header.setSectionResizeMode(QHeaderView.ResizeMode.Interactive)
    # The model draws the sort arrow into the heading itself (mark_sorted).
    header.sortIndicatorChanged.connect(
        lambda column, order: model.mark_sorted(column, order == Qt.SortOrder.AscendingOrder)
    )
    header.setSortIndicator(-1, Qt.SortOrder.AscendingOrder)
    view.setSortingEnabled(True)
    if sort_column is not None:
        order = Qt.SortOrder.AscendingOrder if ascending else Qt.SortOrder.DescendingOrder
        view.sortByColumn(sort_column, order)
    view.resizeColumnsToContents()
    # What each column's values alone need (the header label can elide; they can't).
    values: dict[int, int] = {}
    for column in range(model.columnCount()):
        try:
            need = view.sizeHintForColumn(column)
        except Exception:  # noqa: BLE001 - measured by header and values together only
            continue
        if isinstance(need, int) and need > 0:
            values[column] = min(need + 8, max_column_width)
    for column in range(model.columnCount()):
        if column != stretch_column and header.sectionSize(column) > max_column_width:
            header.resizeSection(column, max_column_width)
        # a little air either side of the widest value
        elif column != stretch_column:
            header.resizeSection(column, header.sectionSize(column) + 8)
    if stretch_column is not None and stretch_column < model.columnCount():
        header.setSectionResizeMode(stretch_column, QHeaderView.ResizeMode.Stretch)
    view.setTextElideMode(Qt.TextElideMode.ElideRight)
    view.column_fitter = ColumnFitter(view, stretch_column, values)
    if fit_rows:
        fit_height(view, model.rowCount(), row_height, fit_rows)
    return view, proxy


def section(title: str, subtitle: str = "") -> QWidget:
    """A page heading block."""
    wrap = QWidget()
    layout = QVBoxLayout(wrap)
    layout.setContentsMargins(0, 0, 0, 0)
    layout.setSpacing(2)
    heading = QLabel(title.upper())
    heading.setObjectName("PageTitle")
    layout.addWidget(heading)
    # the gold rule under the name, as under the dashboard's own in the sidebar
    rule = QFrame()
    rule.setObjectName("TitleRule")
    rule.setFixedSize(46, 3)
    layout.addSpacing(3)
    layout.addWidget(rule)
    layout.addSpacing(5)
    if subtitle:
        sub = QLabel(subtitle)
        sub.setObjectName("PageSubtitle")
        sub.setWordWrap(True)
        layout.addWidget(sub)
    return wrap
