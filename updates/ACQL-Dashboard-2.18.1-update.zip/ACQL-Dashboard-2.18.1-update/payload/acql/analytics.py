"""Season analytics: projections, title odds and the patterns behind the scores.

Everything here is plain computation over the domain model, with no Qt, so it
can be tested on its own and read without a UI around it. The pages only
format what these functions return.

Two sections:

* Looking ahead - how many weeks are left, who can still win, the leader's
  magic number, and title odds from a simulation of the rest of the season.
* Looking back - the home-team record, which weeks were hard, whether a good
  week tends to follow a good week, head-to-head records, and each player's
  form against their consistency.
"""

from __future__ import annotations

import math
import statistics
from dataclasses import dataclass
from functools import lru_cache

import numpy as np

from .config import WEEKS_IN_SEASON
from .models import Game, Player, Season, Week

SIMULATIONS = 10_000
# How many weeks of their own a player needs before their history outweighs
# the pool's. Pick'em results are mostly noise week to week, so this is set
# high: at 3, one hot opening week made a player an 80% title favourite with
# seventeen weeks still to play. At 8, a player's own record only carries
# more weight than the pool's from about the midpoint of the season.
SHRINKAGE_WEEKS = 8
EARLY_WEEKS = 4      # below this, the UI warns that odds will move a lot
SEED = 2026          # fixed, so odds change only when the data does
MIN_MOMENTUM_PAIRS = 8


# ======================================================================
# Looking ahead
# ======================================================================
def weeks_remaining(season: Season) -> int:
    """Weeks still to be finalised. A week in progress counts as remaining."""
    return max(0, WEEKS_IN_SEASON - len(season.final_weeks()))


def max_per_week(season: Season) -> int:
    """The most anyone can add in one week: every game plus every big loser."""
    return season.max_regular_points + season.max_big_loser_points


def current_wins(player: Player) -> int:
    """Season wins as the standings have them.

    stats.xls is authoritative, so its figure is used when present. Without
    a stats export the week sheets are all there is, so they are summed.
    """
    return player.wins or player.season_wins


def history(player: Player) -> list[int]:
    return [v for v in player.weekly_wins.values() if v is not None]


@dataclass(frozen=True)
class Outlook:
    """One player's position and prospects."""

    player: Player
    wins: int
    pace: float           # average wins a week so far
    projected: float      # wins + pace for every remaining week
    best_case: int        # wins + a perfect week, every week left
    title_odds: float     # 0..1, from the simulation
    top3_odds: float      # 0..1
    status: str


@dataclass(frozen=True)
class RaceSummary:
    outlooks: list[Outlook]      # most likely champion first
    remaining: int
    per_week: int
    in_contention: int           # mathematically able to finish first
    magic_number: int | None     # None once the season is over
    leader: Player | None
    chaser: Player | None        # the player with the best best case, bar the leader
    simulations: int


def simulate(
    players: list[Player],
    remaining: int,
    *,
    sims: int = SIMULATIONS,
    seed: int = SEED,
) -> tuple[np.ndarray, np.ndarray]:
    """Title and top-three odds for each player, by simulating the season out.

    Each simulated week, a player scores one of their own past weeks, picked
    at random - a bootstrap of their record. A player with only a few weeks
    has too little history to trust, so each draw comes from the whole pool's
    weeks instead with probability k/(n+k), k = SHRINKAGE_WEEKS: a player is
    treated as typical until they have shown otherwise for a while.

    Ties for first share the title equally, so the odds always sum to one.
    Because every draw is a real past score, nobody can exceed a perfect
    week, and a player who is mathematically out gets exactly zero.
    """
    count = len(players)
    wins = np.array([current_wins(p) for p in players], dtype=float)
    if count == 0:
        return np.zeros(0), np.zeros(0)

    pool = np.array([v for p in players for v in history(p)], dtype=float)
    if remaining == 0 or pool.size == 0:
        # Nothing left to play (or nothing to play it with): the table stands.
        return _odds(wins[:, None])

    rng = np.random.default_rng(seed)
    added = np.zeros((count, sims))
    for i, player in enumerate(players):
        own = np.array(history(player), dtype=float)
        shape = (sims, remaining)
        pooled = pool[rng.integers(pool.size, size=shape)]
        if own.size:
            weight = own.size / (own.size + SHRINKAGE_WEEKS)
            mine = own[rng.integers(own.size, size=shape)]
            draws = np.where(rng.random(shape) < weight, mine, pooled)
        else:
            draws = pooled
        added[i] = draws.sum(axis=1)
    return _odds(wins[:, None] + added)


def _odds(finals: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Turn a (players, sims) table of final totals into title and top-3 odds."""
    best = finals.max(axis=0)
    on_top = finals == best
    title = (on_top / on_top.sum(axis=0)).mean(axis=1)
    # A player's place is one more than the number strictly ahead of them,
    # so players level on points share the better place.
    ahead = (finals[None, :, :] > finals[:, None, :]).sum(axis=1)
    top3 = (ahead < 3).mean(axis=1)
    return title, top3


def race(season: Season, *, sims: int = SIMULATIONS) -> RaceSummary:
    """Everything the Projections tab needs, computed in one pass."""
    players = [p for p in season.players.values()]
    remaining = weeks_remaining(season)
    per_week = max_per_week(season)
    if not players:
        return RaceSummary([], remaining, per_week, 0, None, None, None, 0)

    title, top3 = simulate(players, remaining, sims=sims)
    wins = [current_wins(p) for p in players]
    best_cases = [w + remaining * per_week for w in wins]
    top = max(wins)

    leaders = [p for p, w in zip(players, wins) if w == top]
    leader = sorted(leaders, key=lambda p: p.display.lower())[0]
    # The chaser is whoever could finish highest if everything went their way.
    others = sorted(
        ((b, p) for p, b in zip(players, best_cases) if p.key != leader.key),
        key=lambda o: (-o[0], o[1].display.lower()),
    )
    chaser_best, chaser = others[0] if others else (None, None)
    clinched = remaining > 0 and chaser_best is not None and top > chaser_best

    outlooks = []
    for p, w, b, t, t3 in zip(players, wins, best_cases, title, top3):
        own = history(p)
        pace = sum(own) / len(own) if own else 0.0
        if remaining == 0:
            status = "Champion" if w == top else "Final"
        elif clinched and p.key == leader.key:
            status = "Clinched"
        elif w == top:
            status = "Co-leader" if len(leaders) > 1 else "Leader"
        elif b >= top:
            status = "In contention"
        else:
            status = "Out of the title race"
        outlooks.append(Outlook(
            player=p, wins=w, pace=pace, projected=w + pace * remaining,
            best_case=b, title_odds=float(t), top3_odds=float(t3), status=status,
        ))
    outlooks.sort(key=lambda o: (-o.title_odds, -o.wins, o.player.display.lower()))

    in_contention = sum(1 for b in best_cases if b >= top)
    magic = None
    if remaining > 0 and chaser_best is not None:
        # Baseball's magic number, carried over: each leader win and each
        # point the chaser fails to score brings the clinch one closer.
        magic = max(0, chaser_best - top + 1)
    return RaceSummary(
        outlooks=outlooks, remaining=remaining, per_week=per_week,
        in_contention=in_contention, magic_number=magic,
        leader=leader, chaser=chaser, simulations=sims,
    )


# ======================================================================
# Looking back
# ======================================================================
MIN_HOME_GAMES = 48   # three full weeks; fewer than that is a coin flip's noise


def home_record(season: Season) -> tuple[int, int]:
    """(home wins, decided games) across every game with a result."""
    home = decided = 0
    for week in season.weeks.values():
        for game in week.games:
            result = game.winner_is_home()
            if result is None:
                continue
            decided += 1
            home += int(result)
    return home, decided


@dataclass(frozen=True)
class WeekProfile:
    week: int
    average: float
    best: int
    worst: int
    players: int


def week_profiles(season: Season) -> list[WeekProfile]:
    """How the pool scored each final week: the best, the worst and the mean."""
    out = []
    for week in season.final_weeks():
        scores = [
            p.weekly_wins[week] for p in season.players.values()
            if p.weekly_wins.get(week) is not None
        ]
        if scores:
            out.append(WeekProfile(
                week, sum(scores) / len(scores), max(scores), min(scores), len(scores),
            ))
    return out


def pearson(xs: list[float], ys: list[float]) -> float | None:
    """Correlation, or None when either side has no spread to correlate."""
    if len(xs) < 2:
        return None
    mx, my = sum(xs) / len(xs), sum(ys) / len(ys)
    sxy = sum((x - mx) * (y - my) for x, y in zip(xs, ys))
    sxx = sum((x - mx) ** 2 for x in xs)
    syy = sum((y - my) ** 2 for y in ys)
    if sxx == 0 or syy == 0:
        return None
    return sxy / math.sqrt(sxx * syy)


def momentum(season: Season) -> tuple[float, int] | None:
    """Does a good week predict a good next week? (correlation, pairs used)

    Scores are taken relative to that week's pool average first. Otherwise a
    hard week drags everyone down together and the correlation measures the
    schedule, not the players. What is left is whether beating the pool one
    week goes with beating it the next.
    """
    weeks = season.final_weeks()
    averages = {w.week: w.average for w in week_profiles(season)}
    xs, ys = [], []
    for player in season.players.values():
        for this, following in zip(weeks, weeks[1:]):
            a, b = player.weekly_wins.get(this), player.weekly_wins.get(following)
            if a is None or b is None or this not in averages or following not in averages:
                continue
            xs.append(a - averages[this])
            ys.append(b - averages[following])
    if len(xs) < MIN_MOMENTUM_PAIRS:
        return None
    r = pearson(xs, ys)
    return None if r is None else (r, len(xs))


def describe_momentum(r: float) -> str:
    """Plain words for a correlation, with the usual rough thresholds."""
    if r >= 0.3:
        return "good weeks tend to follow good weeks"
    if r >= 0.1:
        return "a slight carry-over from week to week"
    if r > -0.1:
        return "no carry-over - each week starts fresh"
    if r > -0.3:
        return "a slight bounce-back after bad weeks"
    return "strong weeks tend to be followed by weaker ones"


@dataclass(frozen=True)
class Matchup:
    wins: int      # weeks the row player outscored the column player
    ties: int
    shared: int    # weeks both played

    @property
    def share(self) -> float:
        """Share of shared weeks won, ties counting as half."""
        return (self.wins + 0.5 * self.ties) / self.shared if self.shared else 0.0


def head_to_head(players: list[Player], weeks: list[int]) -> list[list[Matchup | None]]:
    """For every ordered pair, how often the row player beat the column player.

    The diagonal is None: a player does not play themselves.
    """
    grid: list[list[Matchup | None]] = []
    for a in players:
        row: list[Matchup | None] = []
        for b in players:
            if a.key == b.key:
                row.append(None)
                continue
            wins = ties = shared = 0
            for week in weeks:
                x, y = a.weekly_wins.get(week), b.weekly_wins.get(week)
                if x is None or y is None:
                    continue
                shared += 1
                wins += x > y
                ties += x == y
            row.append(Matchup(wins, ties, shared))
        grid.append(row)
    return grid


@dataclass(frozen=True)
class FormPoint:
    player: Player
    average: float
    spread: float     # standard deviation of weekly wins
    weeks: int


def form_profile(season: Season, minimum_weeks: int = 3) -> list[FormPoint]:
    """Average against spread for every player with enough weeks to have one."""
    out = []
    for player in season.players.values():
        own = history(player)
        if len(own) >= minimum_weeks:
            out.append(FormPoint(
                player, sum(own) / len(own), statistics.pstdev(own), len(own),
            ))
    return out


# ======================================================================
# Against the line
# ======================================================================
# How often an NFL regular-season game ends by exactly this margin, as a
# percentage of games: all 4,175 regular-season games from 2010 to 2025
# (the 2010-2026 scores file). Football scores in 3s and 7s, so margins pile
# up on certain numbers - 3, 7, 10, 14, and further out 17, 21, 24, 28, 31,
# 35 - which is exactly where the pool puts its lines. Ties are the rare
# exception to "every margin is possible": thirteen in sixteen seasons,
# because overtime settles almost all of them.
#
# An earlier table stopped at 17 and left out ties, and it showed: the model
# thought a game tied 2% of the time (really 0.3%) and that a 21-point
# blowout was half as common as it is. Checked against the 2021-25 seasons.
MARGIN_FREQUENCY = {
    0: 0.31, 1: 4.43, 2: 4.43, 3: 14.54, 4: 5.01, 5: 3.98, 6: 6.56, 7: 8.69,
    8: 4.14, 9: 1.51, 10: 5.17, 11: 2.06, 12: 1.75, 13: 2.28, 14: 4.98, 15: 1.65,
    16: 2.40, 17: 3.26, 18: 2.40, 19: 1.08, 20: 1.99, 21: 2.44, 22: 1.03, 23: 1.20,
    24: 2.11, 25: 1.22, 26: 0.96, 27: 1.05, 28: 1.60, 29: 0.60, 30: 0.50, 31: 1.15,
    32: 0.48, 33: 0.26, 34: 0.57, 35: 0.62, 36: 0.02, 37: 0.31, 38: 0.43, 39: 0.05,
    40: 0.19, 41: 0.10, 42: 0.12, 43: 0.07, 44: 0.02, 45: 0.10,
}
#: How widely a margin's neighbours are averaged to judge whether it is a key
#: number. A margin twice as common as the margins around it has weight 2.
KEY_SMOOTHING = 3.5
#: A margin seen almost never in sixteen seasons is rare, not impossible.
KEY_FLOOR = 0.2

# The shape of results around the expected margin. Real results are peaked
# AND wide: most games land close to the line, but blowouts happen far more
# often than one bell curve allows. So the curve is two bells with the same
# centre - a narrow one for the ordinary game and a wide one for the day a
# team falls apart - multiplied by the key-number weights.
#
# Fitted to two things at once: the market's win chances (60-61% for a
# 3-point favourite, 74% at 7, 82% at 10 - unchanged from before), and how
# far apart final scores really land (2021-25). Checked on the 2015-20 and
# 2010-14 seasons, which were not used to fit it. Together the two bells put
# results about 14 points either side of the line, as real games are; the
# single curve used before put them about 10 either side, so it made every
# lopsided result look rarer than it is.
SPREAD_SD = 8.7          # width of the narrow bell - the ordinary game
TAIL_RATIO = 2.26        # the wide bell is this many times wider (~19.7 points)
TAIL_SHARE = 0.34        # and carries this share of games
MARGIN_RANGE = range(-60, 61)


def _key_weights() -> dict[int, float]:
    """Each margin's frequency against the average of the margins around it.

    Averaging over neighbours (rather than drawing a line through hand-picked
    "dead" margins) needs no list of which margins are special, reaches all
    the way out to 45, and gives ties their weight straight from the data -
    about a tenth of a 1- or 2-point game.
    """
    reach = 15
    kernel = [math.exp(-(k / KEY_SMOOTHING) ** 2 / 2) for k in range(-reach, reach + 1)]
    total = sum(kernel)
    kernel = [k / total for k in kernel]
    top = max(MARGIN_FREQUENCY)

    def signed(d: int) -> float:
        f = MARGIN_FREQUENCY.get(abs(d), 0.0)
        return f if d == 0 else f / 2           # a margin can go either way

    weights = {}
    for d in range(-top, top + 1):
        smooth = sum(k * signed(d + off) for off, k in zip(range(-reach, reach + 1), kernel))
        here = signed(d)
        weights[d] = here / smooth if here > 0 and smooth > 0 else KEY_FLOOR
    return {abs(d): w for d, w in weights.items() if d >= 0}


KEY_WEIGHT = _key_weights()     # tie ~0.1, 3 ~2.5, 7 ~1.7, 14 ~1.8, 21 ~1.4, 28 ~1.6


_MARGINS = np.array(MARGIN_RANGE, dtype=float)
_KEY_WEIGHTS = np.array([KEY_WEIGHT.get(abs(d), 1.0) for d in MARGIN_RANGE])


def _shape(center: float, sd: float) -> np.ndarray:
    """Chance of each margin in MARGIN_RANGE around `center`, before the mean
    is corrected.

    `sd` is the width of the ordinary game. Callers widen it for a game the
    forecasters disagree about (see `math.hypot(SPREAD_SD, extra)`); that
    extra doubt is about where the centre is, so it widens both bells by the
    same amount rather than stretching them in proportion.

    All 121 margins at once: margin_distribution asks for this forty-one
    times a game, and one margin at a time that was most of the time the
    week's card took to open.
    """
    extra = max(0.0, sd * sd - SPREAD_SD * SPREAD_SD)
    narrow = math.sqrt(SPREAD_SD * SPREAD_SD + extra)
    wide = math.sqrt((SPREAD_SD * TAIL_RATIO) ** 2 + extra)
    off = _MARGINS - center
    bell = (
        (1 - TAIL_SHARE) * np.exp(-(off / narrow) ** 2 / 2) / narrow
        + TAIL_SHARE * np.exp(-(off / wide) ** 2 / 2) / wide
    )
    weights = bell * _KEY_WEIGHTS
    return weights / weights.sum()


@lru_cache(maxsize=1024)
def margin_distribution(spread: float, sd: float = SPREAD_SD) -> tuple[tuple[int, float], ...]:
    """Chance of each final margin, for a team favoured by `spread`.

    A bell curve on its own says a 7-point favourite wins by 7 about as often
    as by 8, which is not how football scores. Each margin is weighted by how
    common it really is, then the curve is shifted so its average margin is
    still the spread - without that shift the key numbers, which cluster near
    zero, drag the average down and every favourite looks weaker than the
    market prices them.
    """
    low, high = spread - 8, spread + 8
    for _ in range(40):                      # bisection on the centre
        mid = (low + high) / 2
        if float(_shape(mid, sd) @ _MARGINS) < spread:
            low = mid
        else:
            high = mid
    return tuple(zip(MARGIN_RANGE, _shape((low + high) / 2, sd).tolist()))


def line_need(line: float) -> int:
    """How many points the pool's favourite has to win by to be credited.

    A win by exactly the line goes to the favourite. That is the
    commissioner's own grading - "(sf by 13)", 49ers 37-24, credited to San
    Francisco on the graded 2025 week 15 sheet - and the pool's rule as Sam
    states it. So a whole-number line needs that many points, and a
    half-point line the next whole number up.
    """
    return math.ceil(line - 1e-9)


@lru_cache(maxsize=4096)
def _at_least(spread: float, sd: float) -> tuple[float, ...]:
    """Chance of winning by at least each margin in MARGIN_RANGE, in its order.

    Every page asks cover_chance thousands of times about a few hundred
    spreads; adding up the same 121 chances for each question was a third of
    the time the week's card took to open. Each is added up here once, in the
    order it always was, so every answer is the same number it was before.
    """
    chances = [p for _, p in margin_distribution(spread, sd)]
    return tuple(sum(chances[i:]) for i in range(len(chances)))


def cover_chance(spread: float, need: int, sd: float = SPREAD_SD) -> float:
    """Chance a team favoured by `spread` wins by at least `need` points."""
    at_least = _at_least(round(spread, 1), sd)
    place = math.ceil(need) - MARGIN_RANGE[0]
    if place >= len(at_least):
        return 0
    return at_least[max(place, 0)]


def win_chance(spread: float) -> float:
    """Chance a team favoured by `spread` simply wins."""
    return cover_chance(spread, 1)


def spread_for_win_chance(chance: float) -> float:
    """The spread at which a team simply wins this often - win_chance, the
    other way round. Negative for an underdog."""
    chance = min(max(float(chance), 0.03), 0.97)
    if chance < 0.5:
        return -spread_for_win_chance(1 - chance)
    low, high = 0.0, 30.0
    for _ in range(30):
        mid = (low + high) / 2
        if win_chance(mid) < chance:
            low = mid
        else:
            high = mid
    return round((low + high) / 2, 1)


def line_threshold(spread: float, most: int = 30, sd: float = SPREAD_SD) -> int:
    """The biggest whole-number pool line the favourite is still worth taking at.

    Useful before the commissioner posts a line: "take them at 6 or less".
    """
    best = 0
    for line in range(most + 1):
        if cover_chance(spread, line_need(line), sd) > 0.5:
            best = line
    return best


# ======================================================================
# The Big Loser mini pool
# ======================================================================
# A big loser is a team that loses by MORE than 14, so 15 is the bar. The
# pool's lines have no effect here - it is the raw result that counts.
BIG_LOSER_MARGIN = 14

# The margin curve above is drawn to say who wins and who covers, and it is
# as good at that as anything tried. At "loses by 15 or more" it is not: set
# against both teams of every regular-season game of 2011-2025 it called
# 13.7% of them big losers where 15.0% were, and it was furthest out just
# where Big Losers are picked - underdogs of 6.5 to 9.5 points, 26% said and
# 32% routed (833 teams; it was 31% in 1999-2010 as well).
#
# So a Big Loser's chance is read off what has happened instead: how often a
# team lost by 15 or more against the closing spread it carried, both teams
# of all 6,967 regular-season games from 1999 to 2025 (nflverse.routs). It is
# a straight line in the odds that may bend at the spreads below. Taught only
# on the seasons before the one it was marked on, it beat the curve - log
# loss 0.3768 against 0.3782, and a third off the gap between said and
# happened. Nothing else earned a place beside the spread: the over/under,
# home field, rest, the roof, the wind, the moneyline, each side's season so
# far and a new quarterback were all tried, and none found more Big Losers
# than the spread alone. rout_fit teaches it again when a season is added.
ROUT_BENDS = (-7.0, -3.0, 0.0, 3.0, 7.0)
ROUT_WEIGHTS = (-1.5871, -1.0274, -0.8341, 0.7874, -0.2620, -0.6055, 0.5223)
#: The seasons ROUT_WEIGHTS was taught on.
ROUT_SEASONS = (1999, 2025)
#: A light hold on the weights while it is taught, so a thin stretch of
#: spreads cannot bend it far.
ROUT_HOLD = 1.0


@dataclass(frozen=True)
class BigLoser:
    """A candidate for the Big Loser pool: a team, and how likely a hiding is."""

    team: str
    opponent: str
    margin: float        # their expected margin, negative when they are the dog
    chance: float        # chance they lose by MORE than BIG_LOSER_MARGIN


def _rout_terms(margin: float) -> list[float]:
    tens = margin / 10
    return [1.0, tens] + [max(0.0, tens - bend / 10) for bend in ROUT_BENDS]


def rout_chance(margin: float) -> float:
    """How often a team with this expected margin has lost by more than 14.

    `margin` is from the team's own side, so -10 means they are ten-point
    underdogs: 36%, where a pick'em is 13% and a ten-point favourite 3%.
    """
    score = sum(w * t for w, t in zip(ROUT_WEIGHTS, _rout_terms(float(margin))))
    return 1 / (1 + math.exp(-score))


def rout_fit(margins, routed, hold: float = ROUT_HOLD) -> tuple[float, ...]:
    """ROUT_WEIGHTS, taught again: each team's spread, and whether it lost by more than 14."""
    terms = np.array([_rout_terms(float(m)) for m in margins])
    lost = np.asarray(routed, dtype=float)
    held = hold * np.eye(terms.shape[1])
    held[0, 0] = 0.0
    weights = np.zeros(terms.shape[1])
    for _ in range(60):
        said = 1 / (1 + np.exp(-terms @ weights))
        weights -= np.linalg.solve((terms * (said * (1 - said))[:, None]).T @ terms + held,
                                   terms.T @ (said - lost) + held @ weights)
    return tuple(round(float(w), 4) for w in weights)


def curve_rout_chance(margin: float, sd: float = SPREAD_SD) -> float:
    """What the margin curve alone makes a team's chance of losing by more
    than 14: the other side clearing 15, which is what cover_chance answers."""
    return cover_chance(-margin, BIG_LOSER_MARGIN + 1, sd)


def _moved(chance: float, was: float, now: float, share: float = 1.0) -> float:
    """`chance`, its odds moved by `share` of the way `was` moved to become `now`."""
    if not (0.0 < chance < 1.0 and 0.0 < was < 1.0 and 0.0 < now < 1.0):
        return chance
    odds = math.log(chance / (1 - chance)) + share * (math.log(now / (1 - now)) - math.log(was / (1 - was)))
    return 1 / (1 + math.exp(-odds))


def big_loser_chance(margin: float, sd: float = SPREAD_SD) -> float:
    """Chance a team with this expected margin loses by more than 14.

    `margin` is from the team's own side, so -10 means they are ten-point
    underdogs. The number is history's (rout_chance). A game priced wider
    than usual - a high over/under, forecasters who disagree - has its odds
    raised by as much as the margin curve raises them for that width, so the
    two still agree about which games are wide open.
    """
    chance = rout_chance(margin)
    if sd <= SPREAD_SD:                      # the curve only ever widens
        return chance
    return _moved(chance, curve_rout_chance(margin), curve_rout_chance(margin, sd))


def big_loser_chance_in_play(live: float, margin: float, sd: float, left: float) -> float:
    """A Big Loser chance read off a game under way, in step with big_loser_chance.

    `live` is what the margins still possible say (gameday.outlook draws them
    off the margin curve); `margin` and `sd` are the team's from before
    kickoff and `left` the share of the game still to play. At kickoff
    history's correction applies in full; as the game is played the score
    takes over, and the correction fades with the time left.
    """
    return _moved(live, curve_rout_chance(margin, sd), big_loser_chance(margin, sd), min(1.0, max(0.0, left)))


def big_losers(games: list[tuple[str, str, float]], sd: float = SPREAD_SD) -> list[BigLoser]:
    """Both teams in every game, worst beating first.

    Each entry is (home, away, expected home margin). Every team is a
    candidate - a favourite can be blown out too, it is just rarer - and the
    list comes back in the order you would pick from it.
    """
    out: list[BigLoser] = []
    for home, away, margin in games:
        out.append(BigLoser(away, home, -margin, big_loser_chance(-margin, sd)))
        out.append(BigLoser(home, away, margin, big_loser_chance(margin, sd)))
    out.sort(key=lambda b: -b.chance)
    return out


def _same(a: object, b: object) -> bool:
    return " ".join(str(a or "").split()).casefold() == " ".join(str(b or "").split()).casefold() != ""


@dataclass(frozen=True)
class LineRecord:
    """A player's picks on games that carried a pool line."""

    correct: int
    decided: int      # lined games with a result, in weeks the player played
    weeks: int        # weeks in which they had at least one decided lined game

    @property
    def rate(self) -> float:
        return self.correct / self.decided if self.decided else 0.0

    @property
    def per_week(self) -> float:
        return self.correct / self.weeks if self.weeks else 0.0


def lined_games(season: Season) -> list[tuple[int, Game]]:
    """(week, game) for every game with a pool line, in slate order."""
    return [
        (number, game)
        for number in sorted(season.weeks)
        for game in season.weeks[number].games
        # getattr: an out-of-date models.py has no line fields at all, and a
        # season with no lines is better than three pages that fail to draw.
        if getattr(game, "line", None) is not None
    ]


def line_records(season: Season) -> dict[str, LineRecord]:
    """Each player's record on lined games that have a result.

    A pick counts when it matches the recorded result, which already has the
    line applied. That holds whether or not the wrong picks have been deleted
    yet, so graded and ungraded weeks score the same way.
    """
    tallies: dict[str, list[int]] = {}
    weeks_seen: dict[str, set[int]] = {}
    for number, game in lined_games(season):
        if not game.played:
            continue
        for key, line in season.weeks[number].lines.items():
            t = tallies.setdefault(key, [0, 0])
            t[1] += 1
            t[0] += _same(line.correct_picks.get(game.index), game.winner)
            weeks_seen.setdefault(key, set()).add(number)
    return {
        key: LineRecord(c, d, len(weeks_seen.get(key, ())))
        for key, (c, d) in tallies.items()
    }


def pool_line_rate(records: dict[str, LineRecord]) -> float:
    """The whole pool's hit rate on lined games: all correct over all decided."""
    decided = sum(r.decided for r in records.values())
    return sum(r.correct for r in records.values()) / decided if decided else 0.0


def underdog_record(season: Season) -> tuple[int, int]:
    """(underdog got the point, lined games decided) so far this season."""
    dog = decided = 0
    for _, game in lined_games(season):
        if game.played:
            decided += 1
            dog += not _same(game.winner, game.line_favourite)
    return dog, decided


@dataclass(frozen=True)
class Prediction:
    pick: str
    chance: float        # probability the pick is right, 0.5..1
    against_line: bool
    reason: str          # short enough for a table cell
    detail: str = ""     # the long version, for a tooltip

    @property
    def coin_flip(self) -> bool:
        return self.chance < 0.52


PICK_EM = 0.25       # a margin this small either way is a coin flip, not a side


def _points(value: float) -> str:
    """7, 6.5, 10.4 - a margin written the way a spread is written."""
    return f"{value:.1f}".rstrip("0").rstrip(".")


def predict(game: Game, vegas_favourite: str | None, points: float | None) -> Prediction | None:
    """The pick for one game, from the Vegas spread and the pool's rule.

    `vegas_favourite` is "home" or "away"; `points` is the Vegas spread. With
    no spread entered there is nothing to predict from, so the answer is None.
    """
    if vegas_favourite not in ("home", "away") or points is None:
        return None
    return predict_margin(game, points if vegas_favourite == "home" else -points)


def predict_margin(
    game: Game,
    home_margin: float | None,
    *,
    sd: float = SPREAD_SD,
    source: str = "Vegas",
) -> Prediction | None:
    """The pick for one game from an expected margin, positive for the home team.

    Straight-up games take whoever is favoured. On a lined game the pool's
    favourite must win by at least the line (line_need): a win by exactly a
    whole-number line goes to the favourite. The chance is that of the
    expected margin clearing that bar, with results spread `sd` points
    either side of it.

    `sd` is a way in for a game nobody agrees about: widen it and every
    chance moves toward a coin flip, which is what disagreement means.
    `source` only names where the margin came from, for the reason text.
    """
    if home_margin is None:
        return None
    sd = round(max(sd, 1.0), 1)

    line = getattr(game, "line", None)
    if line is None:
        if abs(home_margin) < PICK_EM:
            return Prediction(game.home, 0.5, False, "pick 'em", "No favourite.")
        pick = game.home if home_margin > 0 else game.away
        return Prediction(
            pick, cover_chance(abs(home_margin), 1, sd), False,
            f"{pick} by {_points(abs(home_margin))}",
            f"Straight-up game. {source.capitalize()} makes it {pick} by "
            f"{_points(abs(home_margin))}.",
        )

    favourite = getattr(game, "line_favourite", "")
    fav_is_home = _same(favourite, game.home)
    underdog = getattr(game, "line_underdog", "") or (game.away if fav_is_home else game.home)
    fav_margin = home_margin if fav_is_home else -home_margin
    need = line_need(line)
    p_fav = cover_chance(fav_margin, need, sd)
    says = f"{source.capitalize()} makes it {favourite} by {_points(fav_margin)}" \
        if fav_margin >= PICK_EM else f"{source.capitalize()} doesn't even have {favourite} favoured"
    detail = (
        f"{favourite} have to win by {need} or more to take this one; a win by "
        f"{need - 1} or less goes to {underdog}. {says}, which clears {need} "
        f"about {p_fav:.0%} of the time."
    )
    if fav_margin < PICK_EM:
        short = f"{favourite} need {need}+ and aren't even favoured"
    elif p_fav > 0.5:
        short = f"{favourite} need {need}+ and are favoured by {_points(fav_margin)}"
    else:
        short = f"{favourite} need {need}+ but are favoured by only {_points(fav_margin)}"
    if p_fav > 0.5:
        return Prediction(favourite, p_fav, True, short, detail)
    return Prediction(underdog, 1 - p_fav, True, short, detail)


def upcoming_week(season: Season) -> int:
    """The week to predict.

    The week after the last one that is mostly decided - more than half its
    games have a result. So on Sunday night, with only the late games left,
    it looks ahead to next week; on Thursday, with one game in, it stays on
    the week being played.

    The answer may be a week whose sheet is still blank. The parser leaves
    such weeks out of the Season entirely, so this cannot simply pick from
    `season.weeks`; the page says the slate hasn't been entered instead.
    """
    mostly_done = [
        number for number, week in season.weeks.items()
        if week.games and sum(g.played for g in week.games) * 2 > len(week.games)
    ]
    after = max(mostly_done, default=0)
    return min(after + 1, WEEKS_IN_SEASON)


# ======================================================================
# The rest of the pool
# ======================================================================
# A pick'em pool takes the favourite more often than the favourite wins, and
# more so the bigger the number. Published pools sit around 0.19 on this
# curve. This pool is far chalkier: measured over 53 unlined games of its own
# sheets across two seasons (2025 weeks 15-17, 2026 weeks 1-2) it comes out
# at 0.37 - a 3-point favourite on 75% of cards, a 7-point one on 93%, and
# 91% on every favourite of 5 points or more. The practical meaning is that
# an unlined game has almost no leverage in it.
CROWD_SLOPE = 0.37
# On a game with a pool line the crowd mostly ignores the line and takes the
# better team anyway - 75.6% on the pool's favourite over 27 lined games of
# the same sheets, ranging from 40% to 90%. This is where that starts before
# a season's own habit is measured, and how many lined games it takes for
# the measurement to lead.
CHALK_PRIOR = 0.75
CHALK_WEIGHT = 8


def crowd_on_favourite(spread: float) -> float:
    """The share of a pick'em pool expected to take a favourite this big."""
    return 1 / (1 + math.exp(-CROWD_SLOPE * abs(spread)))


def pool_chalk(season: Season) -> tuple[float, int]:
    """(share of this pool that takes the favourite on a lined game, games seen).

    Worked backwards out of the sheets: on a decided game the players still
    holding a pick are the ones who were right, so the share who took the
    pool's favourite is either that share or its complement, depending on
    which way the game went. Shrunk toward CHALK_PRIOR, because a handful of
    lined games is not a habit yet.
    """
    shares = []
    for number, game in lined_games(season):
        if not game.played:
            continue
        players = list(season.weeks[number].lines.values())
        if not players:
            continue
        right = sum(
            1 for entry in players
            if _same(entry.correct_picks.get(game.index), game.winner)
        )
        share = right / len(players)
        shares.append(share if _same(game.winner, game.line_favourite) else 1 - share)
    if not shares:
        return CHALK_PRIOR, 0
    seen = len(shares)
    measured = statistics.fmean(shares)
    return (seen * measured + CHALK_WEIGHT * CHALK_PRIOR) / (seen + CHALK_WEIGHT), seen


def leverage(chance: float, share: float) -> float:
    """Games gained on the average card by making this pick.

    Being right when everyone else is right wins nothing; the whole of the
    gain on the field is the chance of being right minus the share of the
    pool already on that side. It is why a 55% pick that 20% of the pool
    holds is worth more than an 80% pick that 85% of them hold.
    """
    return chance - share


@dataclass(frozen=True)
class Scorecard:
    """How the picks have actually done, against how they said they would."""

    hits: int
    picks: int
    expected: float      # the chances added up: how many it thought it would get
    weeks: int
    lined_hits: int = 0  # of those, the ones played under the pool's line rule
    lined_picks: int = 0

    @property
    def straight_hits(self) -> int:
        """Games picked the ordinary way - who wins, full stop."""
        return self.hits - self.lined_hits

    @property
    def straight_picks(self) -> int:
        return self.picks - self.lined_picks

    @property
    def rate(self) -> float:
        return self.hits / self.picks if self.picks else 0.0

    @property
    def expected_rate(self) -> float:
        return self.expected / self.picks if self.picks else 0.0

    @property
    def surprise(self) -> float:
        """Hits above (or below) what it expected. Near zero is the goal.

        Below zero means the chances are too bold, above means too shy;
        either way, a dozen games is noise, so this needs most of a season
        before it means anything.
        """
        return self.hits - self.expected


def grade(entries: list[tuple[int, Prediction, str]]) -> Scorecard:
    """Score (week, prediction, who actually got the game) against the results.

    The two kinds of pick are counted apart, because they answer different
    questions. A straight game asks who wins and is directly comparable with
    anybody else's record; a lined game asks whether the favourite wins by
    more than the pool's number, which nothing outside this pool is even
    trying to answer. Adding them together and quoting one percentage
    flatters the total.
    """
    hits = sum(1 for _, guess, winner in entries if _same(guess.pick, winner))
    lined = [e for e in entries if e[1].against_line]
    return Scorecard(
        hits=hits,
        picks=len(entries),
        expected=sum(guess.chance for _, guess, _ in entries),
        weeks=len({week for week, _, _ in entries}),
        lined_hits=sum(1 for _, guess, winner in lined if _same(guess.pick, winner)),
        lined_picks=len(lined),
    )


def grade_by_week(entries: list[tuple[int, Prediction, str]]) -> dict[int, Scorecard]:
    """The same scoring, one week at a time, for a chart of how it is going."""
    weeks: dict[int, list[tuple[int, Prediction, str]]] = {}
    for entry in entries:
        weeks.setdefault(entry[0], []).append(entry)
    return {number: grade(rows) for number, rows in sorted(weeks.items())}


#: The confidence bands a pick is sorted into when checking whether its stated
#: chances are honest. Wider than they look useful, because a season is only a
#: few hundred picks and a narrow band is a coin toss with a decimal point.
BANDS = ((0.50, 0.58), (0.58, 0.66), (0.66, 0.75), (0.75, 1.01))


@dataclass(frozen=True)
class Band:
    """One confidence band: what it claimed, and what actually happened."""

    low: float
    high: float
    picks: int
    hits: int
    claimed: float       # the average chance the picks in this band stated

    @property
    def actual(self) -> float:
        return self.hits / self.picks if self.picks else 0.0

    @property
    def gap(self) -> float:
        """Positive means the picks did better than they said they would."""
        return self.actual - self.claimed

    @property
    def label(self) -> str:
        return f"{self.low:.0%}-{self.high if self.high <= 1 else 1:.0%}"


def calibration(entries: list[tuple[int, Prediction, str]]) -> list[Band]:
    """Are the stated chances honest?

    A predictor that says 70% should be right about seven times in ten. Being
    right more often than it claims is not a virtue - it means the chances are
    understated, and every decision made from them, above all whether a pick
    is worth taking against the field, is made on a wrong number.

    Bands with nothing in them are left out rather than drawn as zero, which
    would read as "always wrong" instead of "never tried".
    """
    out: list[Band] = []
    for low, high in BANDS:
        inside = [
            (guess, winner) for _, guess, winner in entries
            if low <= guess.chance < high
        ]
        if not inside:
            continue
        out.append(Band(
            low=low, high=high,
            picks=len(inside),
            hits=sum(1 for guess, winner in inside if _same(guess.pick, winner)),
            claimed=statistics.fmean(guess.chance for guess, _ in inside),
        ))
    return out


@dataclass(frozen=True)
class SlateOutlook:
    expected: float      # picks expected to come in, across the games priced
    priced: int          # games with a spread entered
    strong: int          # picks at 60% or better
    coin_flips: int      # picks too close to call


def slate_outlook(guesses: list[Prediction | None]) -> SlateOutlook:
    """What a week's picks add up to."""
    priced = [g for g in guesses if g is not None]
    return SlateOutlook(
        expected=sum(g.chance for g in priced),
        priced=len(priced),
        strong=sum(1 for g in priced if g.chance >= 0.60),
        coin_flips=sum(1 for g in priced if g.coin_flip),
    )


# ---- the money ---------------------------------------------------------
# The pool's payout rule, taken from the workbook's own formulas rather than
# from a description of them. On each Week sheet:
#
#     AD10  = MAX(B$10:B$44) - B10      how many games behind the best card
#     AD45  = COUNTIF(AD10:AD44, 0)     how many coaches tied for best
#     AD46  = SUM(AD10:AD44) / AD45     the week's pot, split between them
#     A10   = IF(AD10 = 0, $AD$46, " ") and only a winner collects
#
# Which is the rule as the pool states it: a dollar a game for every coach
# your record differs from, collected only by the best card of the week, and
# shared when that card is tied.
#
# It is worked out here because the workbook holds these as formulas and
# saves no cached results, so every cell of it reads as blank from outside
# Excel. The scores are known, and the scores are all this needs.

def week_owed(week: Week) -> dict[str, float]:
    """What each coach's card costs them this week: a dollar a game behind."""
    scores = {
        key: line.total_wins for key, line in week.lines.items()
        if line.total_wins is not None
    }
    if not scores:
        return {}
    best = max(scores.values())
    return {key: float(best - wins) for key, wins in scores.items()}


def week_payouts(week: Week) -> dict[str, float]:
    """What each coach is paid for one week. Only the best card collects."""
    owed = week_owed(week)
    pot = sum(owed.values())
    winners = [key for key, behind in owed.items() if behind == 0]
    if not winners or pot <= 0:
        # Nothing changes hands in a week nobody has played, or one where
        # every coach has the same record and so differs from no one.
        return {}
    share = round(pot / len(winners), 2)
    return {key: share for key in winners}


def fill_winnings(season: Season) -> list[int]:
    """Work out the money for any week the files don't already give.

    A week the workbook or stats.xls has already priced is left alone: those
    are what the pool settled on, and a computed figure that disagrees with
    the cheque someone was handed is worse than no figure. Returns the weeks
    it filled in, so a page can say which numbers it worked out for itself.
    """
    computed: list[int] = []
    for number, week in sorted(season.weeks.items()):
        if any(p.weekly_winnings.get(number) for p in season.players.values()):
            continue
        if week.games and not all(game.played for game in week.games):
            continue        # a week still being played pays nobody yet
        paid = week_payouts(week)
        if not paid:
            continue
        for key, amount in paid.items():
            person = season.players.get(key)
            if person is not None:
                person.weekly_winnings[number] = amount
        computed.append(number)

    # The season totals stats.xls would carry, for a pool running without it.
    if computed and not any(
        p.points_won or p.points_paid or p.net_points for p in season.players.values()
    ):
        for key, person in season.players.items():
            person.points_won = round(sum(person.weekly_winnings.values()), 2)
            person.points_paid = round(
                sum(week_owed(week).get(key, 0.0) for week in season.weeks.values()), 2
            )
            person.net_points = round(person.points_won - person.points_paid, 2)
        season.computed_totals = True
    return computed
